(* ::Package:: *)

(* Input: GAP ID of a finite group G *)
(* Return {} if G has no almost (5,3)-characters of G *)
(* Otherwise, return the following information for each 3-equivalence class of almost (5,3)-characters of G *)
(* (1) A representative element of the 3-equivalence class of almost (5,3)-characters of G with respect to irreducible representations (see LHsnewLHsnewred.txt) *)
(* (2) Generators of a corresponding almost (5,3)-representation *)
(* (3) A basis of the space of homogeneous polynomials of degree 3 invariant by these generators *)
(* (4) The result of the combinatorial smoothness criterion (CSC, see Lemma 5.8 in the paper) for the list of monomials appeared in the basis *)
(* (4') If CSC cannot determine smoothness, apply Jacobian test for polynomials given by the basis equipped with random coefficients *)
(* In (4), return 0 if non-smoothness follows from CSC; return 1 if there is a smooth form with random coefficients; return 2 otherwise *)
AFTinf[id_]:=Block[{i,out,L,repdims,anslist,read,out2,out3,readchis,chis,app,read2,ordF,app2,r,tab,inf,xi3,xi4,xi5,xi6,xi7,xi8,xi9,xi10,xi11,xi12,xi13,xi14,xi15,xi16,xi17,xi18,xi19,xi20,xi21,xi22,xi23,xi24,xi25,xi26,xi27,xi28,xi29,xi30,xi31,xi32,xi33,xi34,xi35,xi36,xi37,xi38,xi39,xi40,xi41,xi42,xi43,xi44,xi45,xi46,xi47,xi48,xi49,xi50,xi51,xi52,xi53,xi54,xi55,xi56,xi57,xi58,xi59,xi60,xi61,xi62,xi63,xi64,xi65,xi66,xi67,xi68,xi69,xi70,xi71,xi72,xi73,xi74,xi75,xi76,xi77,xi78,xi79,xi80,xi81,xi82,xi83,xi84,xi85,xi86,xi87,xi88,xi89,xi90,xi91,xi92,xi93,xi94,xi95,xi96,xi97,xi98,xi99,xi100,xi101,xi102,xi103,xi104,xi105,xi106,xi107,xi108,xi109,xi110,xi111,xi112,xi113,xi114,xi115,xi116,xi117,xi118,xi119,xi120,xi121,xi122,xi123,xi124,xi125,xi126,xi127,xi128,xi129,xi130,xi131,xi132,xi133,xi134,xi135,xi136,xi137,xi138,xi139,xi140,xi141,xi142,xi143,xi144,xi145,xi146,xi147,xi148,xi149,xi150,xi151,xi152,xi153,xi154,xi155,xi156,xi157,xi158,xi159,xi160,xi161,xi162,xi163,xi164,xi165,xi166,xi167,xi168,xi169,xi170,xi171,xi172,xi173,xi174,xi175,xi176,xi177,xi178,xi179,xi180,xi181,xi182,xi183,xi184,xi185,xi186,xi187,xi188,xi189,xi190,xi191,xi192,xi193,xi194,xi195,xi196,xi197,xi198,xi199,xi200},out=OpenWrite["/tmp/gap.in",FormatType->OutputForm,PageWidth->Infinity];
Write[out,"Read(\"/Users/zzg/Documents/GAPcodes/LHsnewLHsnewred.txt\");"];
Write[out,"Read(\"/Users/zzg/Documents/GAPcodes/GAPcodesnewforMath.txt\");"];
Write[out,"restrictionMatrixListInfII(["<>ToString[id[[1]],InputForm]<>","<>ToString[id[[2]],InputForm]<>"]);"];
Write[out,"quit;"];
Close[out];
Run["gap -q -s 160000000 < /tmp/gap.in > /tmp/gap.out"];
Run["sed '/#/'d < /tmp/gap.out > /tmp/gap.math"];
Run["sed 's/\[/{/g;s/\]/}/g;s/>//g' < /tmp/gap.math > /tmp/gap.math2"];
read=OpenRead["/tmp/gap.math2"];
{L,repdims}=Read[read];anslist=CandFTRepsbyResMatList[L,repdims];If[Length[anslist]==0,Return[{}]];out2=OpenWrite["/tmp/gap2.in",FormatType->OutputForm,PageWidth->Infinity];
Write[out2,"Read(\"/Users/zzg/Documents/GAPcodes/LHsnewLHsnewred.txt\");"];
Write[out2,"Read(\"/Users/zzg/Documents/GAPcodes/GAPcodesnewforMath.txt\");"];
Write[out2,"reps:="<>ToString[anslist,InputForm]<>";;"];
Write[out2,"id:=["<>ToString[id[[1]],InputForm]<>","<>ToString[id[[2]],InputForm]<>"];;"];
Write[out2,"takeonerepfromorbits(id,reps);;"];
Write[out2,"orbs:=takeonerepfromPGLorbits(id,last);;"];
Write[out2,"List(orbs,x->generatorsofrep(id,x));"];
Write[out2,"quit;"];
Close[out2];
Run["sed 's/{/\[/g;s/}/\]/g' < /tmp/gap2.in > /tmp/gap2.gapin"];
Run["gap -q -s 160000000 < /tmp/gap2.gapin > /tmp/gap2.out"];
Run["sed '/#/'d < /tmp/gap2.out > /tmp/gap2.sage"];
Run["sed 's/E(/UCF.gen(/g;s/>//g' < /tmp/gap2.sage > /tmp/gap2.sage2"];out3=OpenWrite["/tmp/gap3.in",FormatType->OutputForm,PageWidth->Infinity];
Write[out3,"Read(\"/Users/zzg/Documents/GAPcodes/LHsnewLHsnewred.txt\");"];
Write[out3,"Read(\"/Users/zzg/Documents/GAPcodes/GAPcodesnewforMath.txt\");"];
Write[out3,"reps:="<>ToString[anslist,InputForm]<>";;"];
Write[out3,"id:=["<>ToString[id[[1]],InputForm]<>","<>ToString[id[[2]],InputForm]<>"];;"];
Write[out3,"takeonerepfromorbits(id,reps);;"];
Write[out3,"orbs:=takeonerepfromPGLorbits(id,last);"];
Write[out3,"quit;"];
Close[out3];
Run["sed 's/{/\[/g;s/}/\]/g' < /tmp/gap3.in > /tmp/gap3.gapin"];
Run["gap -q -s 160000000 < /tmp/gap3.gapin > /tmp/gap3.out"];
Run["sed '/#/'d < /tmp/gap3.out > /tmp/gap3.math"];
Run["sed 's/E(/xi/g;s/)//g;s/\[/{/g;s/\]/}/g;s/>//g' < /tmp/gap3.math > /tmp/gap3.math2"];
readchis=OpenRead["/tmp/gap3.math2"];
chis=Read[readchis];app=OpenAppend["/tmp/gap2.sage"];
Write[app,";;L:=last;;"];
Write[app,"CFfieldGene:=function(L) local i;for i in [1..1000] do if CF(i)=CyclotomicField(Flat(L)) then return i; fi;od;end;;"];
Write[app,"CFfieldGene(L);"];
Close[app];
Run["sed 's/\"//g' < /tmp/gap2.sage > /tmp/field.gap"];
Run["gap -q -s 160000000 < /tmp/field.gap > /tmp/field.gap2"];
FilePrint["/tmp/field.gap2"];
read2=OpenRead["/tmp/field.gap2"];
ordF=Read[read2];Run["sed -i.backup '1s/^/UCF = UniversalCyclotomicField();L=/' /tmp/gap2.sage2"];
app2=OpenAppend["/tmp/gap2.sage2"];
Write[app2,"F=CyclotomicField("<>ToString[ordF,InputForm]<>")"];Write[app2,"MS=MatrixSpace(F,7,7)"];
Write[app2,"matlist=[MatrixGroup([MS(p) for p in i]) for i in L]"];
Write[app2,"[[L[j],matlist[j].order(),matlist[j].invariants_of_degree(3)]for j in [0..len(matlist)-1]]"];
(*Write[app2,"quit"];*)
Close[app2];
Run["sed 's/\"//g' < /tmp/gap2.sage2 > /tmp/gap2.sage3"];
Run["sage -q < /tmp/gap2.sage3 > /tmp/gap2.sage4"];
Run["sed 's/://g;s/sage//g;s/\[/{/g;s/\]/}/g;s/E(/(xi/g;s/zeta/xi/g' < /tmp/gap2.sage4 > /tmp/table.math2"];Run["sed 's/{{{{{/*){{{{{/g' </tmp/table.math2> /tmp/table.math3"];
Run["sed -i.backup '1s/^/(*/' /tmp/table.math3"];
{xi3,xi4,xi5,xi6,xi7,xi8,xi9,xi10,xi11,xi12,xi13,xi14,xi15,xi16,xi17,xi18,xi19,xi20,xi21,xi22,xi23,xi24,xi25,xi26,xi27,xi28,xi29,xi30,xi31,xi32,xi33,xi34,xi35,xi36,xi37,xi38,xi39,xi40,xi41,xi42,xi43,xi44,xi45,xi46,xi47,xi48,xi49,xi50,xi51,xi52,xi53,xi54,xi55,xi56,xi57,xi58,xi59,xi60,xi61,xi62,xi63,xi64,xi65,xi66,xi67,xi68,xi69,xi70,xi71,xi72,xi73,xi74,xi75,xi76,xi77,xi78,xi79,xi80,xi81,xi82,xi83,xi84,xi85,xi86,xi87,xi88,xi89,xi90,xi91,xi92,xi93,xi94,xi95,xi96,xi97,xi98,xi99,xi100,xi101,xi102,xi103,xi104,xi105,xi106,xi107,xi108,xi109,xi110,xi111,xi112,xi113,xi114,xi115,xi116,xi117,xi118,xi119,xi120,xi121,xi122,xi123,xi124,xi125,xi126,xi127,xi128,xi129,xi130,xi131,xi132,xi133,xi134,xi135,xi136,xi137,xi138,xi139,xi140,xi141,xi142,xi143,xi144,xi145,xi146,xi147,xi148,xi149,xi150,xi151,xi152,xi153,xi154,xi155,xi156,xi157,xi158,xi159,xi160,xi161,xi162,xi163,xi164,xi165,xi166,xi167,xi168,xi169,xi170,xi171,xi172,xi173,xi174,xi175,xi176,xi177,xi178,xi179,xi180,xi181,xi182,xi183,xi184,xi185,xi186,xi187,xi188,xi189,xi190,xi191,xi192,xi193,xi194,xi195,xi196,xi197,xi198,xi199,xi200}=Table[E^(2Pi*I/i),{i,3,200}];
r=OpenRead["/tmp/table.math3"];
tab=Read[r];inf=CSCforAFTs[tab,chis,5,3];Return[inf]]

(* Input: GAP ID of a finite group G *)
(* Return {} if R_G in Strategy 5.16 in the paper is empty *)
(* Otherwise, return the following information for each 3-equivalence class of special almost (5,3)-characters of G *)
(* (1) A representative element of the 3-equivalence class of special almost (5,3)-characters of G with respect to irreducible representations (see LHsnewLHsnewred.txt) *)
(* (2) Generators of a corresponding special almost (5,3)-representation *)
(* (3) A basis of the space of homogeneous polynomials of degree 3 invariant by these generators *)
(* (4) The result of the combinatorial smoothness criterion (CSC, see Lemma 5.8 in the paper) for the list of monomials appeared in the basis *)
(* (4') If CSC cannot determine smoothness, apply Jacobian test for polynomials given by the basis equipped with random coefficients *)
(* In (4), return 0 if non-smoothness follows from CSC; return 1 if there is a smooth form with random coefficients; return 2 otherwise *)
AFTinfred[id_]:=Block[{i,out,L,repdims,anslist,read,out2,out3,readchis,chis,app,read2,ordF,app2,r,tab,inf,xi3,xi4,xi5,xi6,xi7,xi8,xi9,xi10,xi11,xi12,xi13,xi14,xi15,xi16,xi17,xi18,xi19,xi20,xi21,xi22,xi23,xi24,xi25,xi26,xi27,xi28,xi29,xi30,xi31,xi32,xi33,xi34,xi35,xi36,xi37,xi38,xi39,xi40,xi41,xi42,xi43,xi44,xi45,xi46,xi47,xi48,xi49,xi50,xi51,xi52,xi53,xi54,xi55,xi56,xi57,xi58,xi59,xi60,xi61,xi62,xi63,xi64,xi65,xi66,xi67,xi68,xi69,xi70,xi71,xi72,xi73,xi74,xi75,xi76,xi77,xi78,xi79,xi80,xi81,xi82,xi83,xi84,xi85,xi86,xi87,xi88,xi89,xi90,xi91,xi92,xi93,xi94,xi95,xi96,xi97,xi98,xi99,xi100,xi101,xi102,xi103,xi104,xi105,xi106,xi107,xi108,xi109,xi110,xi111,xi112,xi113,xi114,xi115,xi116,xi117,xi118,xi119,xi120,xi121,xi122,xi123,xi124,xi125,xi126,xi127,xi128,xi129,xi130,xi131,xi132,xi133,xi134,xi135,xi136,xi137,xi138,xi139,xi140,xi141,xi142,xi143,xi144,xi145,xi146,xi147,xi148,xi149,xi150,xi151,xi152,xi153,xi154,xi155,xi156,xi157,xi158,xi159,xi160,xi161,xi162,xi163,xi164,xi165,xi166,xi167,xi168,xi169,xi170,xi171,xi172,xi173,xi174,xi175,xi176,xi177,xi178,xi179,xi180,xi181,xi182,xi183,xi184,xi185,xi186,xi187,xi188,xi189,xi190,xi191,xi192,xi193,xi194,xi195,xi196,xi197,xi198,xi199,xi200},out=OpenWrite["/tmp/gap.in",FormatType->OutputForm,PageWidth->Infinity];
Write[out,"Read(\"/Users/zzg/Documents/GAPcodes/LHsnewLHsnewred.txt\");"];
Write[out,"Read(\"/Users/zzg/Documents/GAPcodes/GAPcodesnewforMath.txt\");"];
Write[out,"restrictionMatrixListInfIIred(["<>ToString[id[[1]],InputForm]<>","<>ToString[id[[2]],InputForm]<>"]);"];
Write[out,"quit;"];
Close[out];
Run["gap -q -s 160000000 < /tmp/gap.in > /tmp/gap.out"];
Run["sed '/#/'d < /tmp/gap.out > /tmp/gap.math"];
Run["sed 's/\[/{/g;s/\]/}/g;s/>//g' < /tmp/gap.math > /tmp/gap.math2"];
read=OpenRead["/tmp/gap.math2"];
{L,repdims}=Read[read];anslist=CandFTRepsbyResMatList[L,repdims];If[Length[anslist]==0,Return[{}]];out2=OpenWrite["/tmp/gap2.in",FormatType->OutputForm,PageWidth->Infinity];
Write[out2,"Read(\"/Users/zzg/Documents/GAPcodes/LHsnewLHsnewred.txt\");"];
Write[out2,"Read(\"/Users/zzg/Documents/GAPcodes/GAPcodesnewforMath.txt\");"];
Write[out2,"reps:="<>ToString[anslist,InputForm]<>";;"];
Write[out2,"id:=["<>ToString[id[[1]],InputForm]<>","<>ToString[id[[2]],InputForm]<>"];;"];
Write[out2,"takeonerepfromorbits(id,reps);;"];
Write[out2,"orbs:=takeonerepfromPGLorbits(id,last);;"];
Write[out2,"List(orbs,x->generatorsofrep(id,x));"];
Write[out2,"quit;"];
Close[out2];
Run["sed 's/{/\[/g;s/}/\]/g' < /tmp/gap2.in > /tmp/gap2.gapin"];
Run["gap -q -s 160000000 < /tmp/gap2.gapin > /tmp/gap2.out"];
Run["sed '/#/'d < /tmp/gap2.out > /tmp/gap2.sage"];
Run["sed 's/E(/UCF.gen(/g;s/>//g' < /tmp/gap2.sage > /tmp/gap2.sage2"];out3=OpenWrite["/tmp/gap3.in",FormatType->OutputForm,PageWidth->Infinity];
Write[out3,"Read(\"/Users/zzg/Documents/GAPcodes/LHsnewLHsnewred.txt\");"];
Write[out3,"Read(\"/Users/zzg/Documents/GAPcodes/GAPcodesnewforMath.txt\");"];
Write[out3,"reps:="<>ToString[anslist,InputForm]<>";;"];
Write[out3,"id:=["<>ToString[id[[1]],InputForm]<>","<>ToString[id[[2]],InputForm]<>"];;"];
Write[out3,"takeonerepfromorbits(id,reps);;"];
Write[out3,"orbs:=takeonerepfromPGLorbits(id,last);"];
Write[out3,"quit;"];
Close[out3];
Run["sed 's/{/\[/g;s/}/\]/g' < /tmp/gap3.in > /tmp/gap3.gapin"];
Run["gap -q -s 160000000 < /tmp/gap3.gapin > /tmp/gap3.out"];
Run["sed '/#/'d < /tmp/gap3.out > /tmp/gap3.math"];
Run["sed 's/E(/xi/g;s/)//g;s/\[/{/g;s/\]/}/g;s/>//g' < /tmp/gap3.math > /tmp/gap3.math2"];
readchis=OpenRead["/tmp/gap3.math2"];
chis=Read[readchis];app=OpenAppend["/tmp/gap2.sage"];
Write[app,";;L:=last;;"];
Write[app,"CFfieldGene:=function(L) local i;for i in [1..1000] do if CF(i)=CyclotomicField(Flat(L)) then return i; fi;od;end;;"];
Write[app,"CFfieldGene(L);"];
Close[app];
Run["sed 's/\"//g' < /tmp/gap2.sage > /tmp/field.gap"];
Run["gap -q -s 160000000 < /tmp/field.gap > /tmp/field.gap2"];
FilePrint["/tmp/field.gap2"];
read2=OpenRead["/tmp/field.gap2"];
ordF=Read[read2];Run["sed -i.backup '1s/^/UCF = UniversalCyclotomicField();L=/' /tmp/gap2.sage2"];
app2=OpenAppend["/tmp/gap2.sage2"];
Write[app2,"F=CyclotomicField("<>ToString[ordF,InputForm]<>")"];Write[app2,"MS=MatrixSpace(F,7,7)"];
Write[app2,"matlist=[MatrixGroup([MS(p) for p in i]) for i in L]"];
Write[app2,"[[L[j],matlist[j].order(),matlist[j].invariants_of_degree(3)]for j in [0..len(matlist)-1]]"];
(*Write[app2,"quit"];*)
Close[app2];
Run["sed 's/\"//g' < /tmp/gap2.sage2 > /tmp/gap2.sage3"];
Run["sage -q < /tmp/gap2.sage3 > /tmp/gap2.sage4"];
Run["sed 's/://g;s/sage//g;s/\[/{/g;s/\]/}/g;s/E(/(xi/g;s/zeta/xi/g' < /tmp/gap2.sage4 > /tmp/table.math2"];Run["sed 's/{{{{{/*){{{{{/g' </tmp/table.math2> /tmp/table.math3"];
Run["sed -i.backup '1s/^/(*/' /tmp/table.math3"];
{xi3,xi4,xi5,xi6,xi7,xi8,xi9,xi10,xi11,xi12,xi13,xi14,xi15,xi16,xi17,xi18,xi19,xi20,xi21,xi22,xi23,xi24,xi25,xi26,xi27,xi28,xi29,xi30,xi31,xi32,xi33,xi34,xi35,xi36,xi37,xi38,xi39,xi40,xi41,xi42,xi43,xi44,xi45,xi46,xi47,xi48,xi49,xi50,xi51,xi52,xi53,xi54,xi55,xi56,xi57,xi58,xi59,xi60,xi61,xi62,xi63,xi64,xi65,xi66,xi67,xi68,xi69,xi70,xi71,xi72,xi73,xi74,xi75,xi76,xi77,xi78,xi79,xi80,xi81,xi82,xi83,xi84,xi85,xi86,xi87,xi88,xi89,xi90,xi91,xi92,xi93,xi94,xi95,xi96,xi97,xi98,xi99,xi100,xi101,xi102,xi103,xi104,xi105,xi106,xi107,xi108,xi109,xi110,xi111,xi112,xi113,xi114,xi115,xi116,xi117,xi118,xi119,xi120,xi121,xi122,xi123,xi124,xi125,xi126,xi127,xi128,xi129,xi130,xi131,xi132,xi133,xi134,xi135,xi136,xi137,xi138,xi139,xi140,xi141,xi142,xi143,xi144,xi145,xi146,xi147,xi148,xi149,xi150,xi151,xi152,xi153,xi154,xi155,xi156,xi157,xi158,xi159,xi160,xi161,xi162,xi163,xi164,xi165,xi166,xi167,xi168,xi169,xi170,xi171,xi172,xi173,xi174,xi175,xi176,xi177,xi178,xi179,xi180,xi181,xi182,xi183,xi184,xi185,xi186,xi187,xi188,xi189,xi190,xi191,xi192,xi193,xi194,xi195,xi196,xi197,xi198,xi199,xi200}=Table[E^(2Pi*I/i),{i,3,200}];
r=OpenRead["/tmp/table.math3"];
tab=Read[r];inf=CSCforAFTs[tab,chis,5,3];Return[inf]]

(* The following two functions are used to determine almost (5,3)-reps by considering the (5,3)-characters of its abelian subgroups *)
(* A: restriction matrix from G to H via some embedding from H -> G *)
(* FTofH: all (5,3)-characters of H with respect to Irr(H) *)
(* repdims: list of dimensions of irreducible representations of G with respect to Irr(G) *)
CandFTRepsbyResMat[A_,FTofH_,repdims_]:=Block[{var,x,i,k,anslist,nonneq,eqdim7,reseq,sol},var=Table[x[i],{i,1,Length[repdims]}];
nonneq=Table[var[[i]]>=0,{i,1,Length[var]}];
eqdim7={(var . repdims==7)};anslist={};
For[k=1,k<=Length[FTofH],k++,Print["k=",k];
reseq=Table[((var . A)[[i]]==(FTofH[[k]])[[i]]),{i,1,Length[FTofH[[k]]]}];
sol=Solve[Join[nonneq,eqdim7,reseq],var,Integers];
If[Length[sol]>0,sol=(var/. sol);
Print[Length[sol]," solutions"];anslist=Join[anslist,sol],Print["no solution for this k"]]];
Print[Length[anslist]," candidates found"];Return[anslist]]

(* L={{FTofH1,A1},{FTofH2,A2},...}, where A1 is the restriction matrix from G to H1 via some embedding from H1 -> G *)
(* FTofH1: all (5,3)-characters of H with respect to Irr(H1) *)
(* repdims: list of dimensions of irreducible representations of G with respect to Irr(G) *)
(* |H1| needs to be relatively large to compute CandFTRepsbyResMat[A1,FTofH1,repdims] *)
(* if L includes all possible embeddings of proper abelian subgroups into G, then the output is the list of almost (5,3)-reps of G *)
CandFTRepsbyResMatList[L_,repdims_]:=Block[{A,FTofH,i,anslist,n},{FTofH,A}=L[[1]];
anslist=CandFTRepsbyResMat[A,FTofH,repdims];
If[Length[anslist]==0,Return[{}]];n=Length[L];
For[i=2,i<=n,i++,A=L[[i,2]];FTofH=L[[i,1]];
anslist=Select[anslist,MemberQ[FTofH,# . A]&];
Print[Length[anslist]," candidates left after test by ",i,"-th abelian subgroup embedding"];
If[Length[anslist]==0,Return[{}]]];Return[anslist]]

(* Partition the list l into segments, where the sizes of the segments are specified by the list p *)
dynP[l_,p_]:=MapThread[l[[#;;#2]]&,{{0}~Join~Most@#+1,#}&@Accumulate@p]

(* n: dimension of hypersurface *)
(* Return the list of all tuples (v1,v2,v3), where vi are sets of integers such that the union of v1,v2,v3 is {1,...,n+2} and |v1|>|v2| *)
AllDecomposition[n_]:=Block[{Permu,PartiList,DecompList,Decomps,parti,i},PartiList=AllPartition[n];
DecompList={};
For[i=1,i<Length[PartiList]+1,i++,parti=PartiList[[i]];
Decomps=DecompositionForCertainPartition[parti,n];
AppendTo[DecompList,Decomps]];
DecompList=Flatten[DecompList,1];
Return[DecompList]]

(* Return all possible tuples of integers (a1,a2,a3) such that a1+a2+a3=n+2 and a1>a2 *)
AllPartition[n_]:=Block[{PartiList},PartiList=Select[Tuples[Range[0,n+2],3],Total@#==n+2&];
PartiList=Select[PartiList,#[[1]]>#[[2]]&];
Return[PartiList];]

(* parti: a given tuple of integers (a1,a2,a3) with a1+a2+a3=n+2 *)
(* Partition the list {1,...,n+2} into three disjoint subsets of sizes a1,a2 and a3 *)
DecompositionForCertainPartition[parti_,n_]:=Block[{Permu,DecompList},Permu=Permutations[Range[1,n+2]];
DecompList=dynP[#,parti]&/@Permu;
DecompList=Map[Sort,DecompList,{2}];
DecompList=DeleteDuplicates[DecompList];
Return[DecompList];]

(* v: a sublist of {1, ..., n+2} *)
(* Return a list (called the position list of v) with the i-th element being 1 if i is in v, 0 otherwise *)
PositionList[v_,n_]:=Block[{listvi,vi},vi=Map[List[#]&,v];
listvi=ReplacePart[ConstantArray[0,n+2],vi->1];
Return[listvi];]

(* table: a list of monomials in an exponential form, e.g., x1^2x4 -> {2, 0, 0, 1, 0, 0, 0} *)
(* Listv0, Listv1, Listv2: position lists of given sublists of {1, ..., n+2} *)
(* n and d are the dimension and degree, respectively *)
(* Check Lemma 5.8 (i)-(iii) for given V1, V2 and V3 cooresponding to Listv0, Listv1 and Listv2, respectively *)
CertainDecompsitionTest[table_,Listv0_,Listv1_,Listv2_,n_,d_]:=Block[{degv0,degv1,degv2,i},For[i=1,i<Length[table]+1,i++,degv0=Total[Pick[table[[i]],Listv0,1]];
degv1=Total[Pick[table[[i]],Listv1,1]];
degv2=Total[Pick[table[[i]],Listv2,1]];
If[!((degv0==d-1&&degv1==1)||(degv0==1&&degv1+degv2==d-1)||(degv1+degv2==d)),Return[1]]];
Return[2]]

(* tab: contains information on the faithful representations of a group *)
(* chis: character lists of the representations *)
(* Print the information and apply the smoothness test for the monomials that are invariant under the representation matrices *)
CSCforAFTs[tab_,chis_,n_,d_]:=Block[{i,j,basislist,relist,testre},relist={};
For[i=1,i<Length[tab]+1,i++,basislist=tab[[i,3]];
Print[i];
Print[chis[[i]]];
For[j=1,j<Length[tab[[i,1]]]+1,j++,Print[j,"-th generator"];
Print[MatrixForm[tab[[i,1,j]]]];
Print[" "]];
Print["order of group is"];Print[tab[[i,2]]];
If[CSCforbasis[basislist,n,d]==1,testre=RandomTestII[basislist,n];
AppendTo[relist,{chis[[i]],testre,tab[[i,1]],tab[[i,3]]}],AppendTo[relist,{chis[[i]],0,tab[[i,1]],tab[[i,3]]}]]];
Return[relist]]

(* table: a list of monomials; DecompList: a list of tuples of integers (a1,a2,a3) with a1+a2+a3=n+2 *)
(* the smoothness test can be conducted for a given form F with n+2 variables and all monomials in "table" *)
(* Return 2 if the condition in Lemma 5.8 does not hold, indicating that F is not smooth *)
(* Return 1 if the condition holds and the smoothness requires further checking *)
NewSmoothnessTestII[table_,DecompList_,n_,d_]:=Block[{decomp,v0,v1,v2,Listv0,Listv1,Listv2,degv0,degv1,degv2,j},For[j=1,j<Length[DecompList]+1,j++,decomp=DecompList[[j]];
v0=decomp[[1]];Listv0=PositionList[v0,n];
v1=decomp[[2]];Listv1=PositionList[v1,n];
v2=decomp[[3]];Listv2=PositionList[v2,n];
If[CertainDecompsitionTest[table,Listv0,Listv1,Listv2,n,d]!=1,Print["{V1,V2,V3}: "];
Print[{(#-1)&/@v0,(#-1)&/@v1,(#-1)&/@v2}];
Print["not smooth by CSC"];Return[2]]];
Return[1]]

(* basislist: a list of polynomials in {x0, ..., x6} *)
(* Extract the monomials appearing in basislist into a list, then conduct the smoothness test (apply "NewSmoothnessTestII") for this list of monomials *)
CSCforbasis[basislist_,n_,d_]:=Block[{cubic,DecompList},Print["monomils involved: "];
Print[(Flatten[MonomialList[#]&/@basislist])];
cubic=Exponent[#,Table[Symbol["x"<>ToString[i]],{i,0,n+1}]]&/@(Flatten[MonomialList[#]&/@basislist]);
DecompList=AllDecomposition[n];
Return[NewSmoothnessTestII[cubic,DecompList,n,d]]]

(* Return 1 if a smooth form F given by linear combination of polynomials in "basislist" can be found *)
(* Return 2 if no such F is found *)
RandomTestII[basislist_,n_]:=Block[{i,random},For[i=1,i<5,i++,random=RandomInteger[{1,100},Length[basislist]];
If[SmoothnessTestII[basislist,random,n]==1,Return[1]]];
Return[2]]

(* random: a list of (complex) numbers of length equal to that of "basislist" *)
(* Return 0 if the form given by the sum of polynomials in "basislist" equipped with coefficients in "ramdom" (in input order) is smooth *)
(* Return 1 if such a form is not smooth *)
SmoothnessTestII[basislist_,random_,n_]:=Block[{i,var,cubic,eq,sol,min},cubic=basislist . random;
var=Table[Symbol["x"<>ToString[i]],{i,0,n+1}];
Print["a test with random coefficients: ",cubic];
eq=D[cubic,#]==0&/@var;sol=Solve[eq,var];
Print[" solution for the partial derivatives: ",sol];
min=Min[Map[Length[#]&,sol]];
If[min==n+2,Return[1],Return[0]]]
